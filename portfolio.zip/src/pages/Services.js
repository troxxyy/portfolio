
import React from 'react';

function Services() {
  return (
    <div>
      <h1>Services</h1>
      <ul>
        <li>Web Development</li>
        <li>Mobile App Development</li>
        <li>AR/VR Solutions</li>
      </ul>
    </div>
  );
}

export default Services;
