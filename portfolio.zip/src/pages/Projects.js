
import React from 'react';

function Projects() {
  return (
    <div>
      <h1>Projects</h1>
      <div>
        <h2>Project 1</h2>
        <p>Description of Project 1</p>
      </div>
      <div>
        <h2>Project 2</h2>
        <p>Description of Project 2</p>
      </div>
      <div>
        <h2>Project 3</h2>
        <p>Description of Project 3</p>
      </div>
    </div>
  );
}

export default Projects;
