
import React from 'react';

function Home() {
  return (
    <div>
      <h1>Welcome to my Portfolio</h1>
      <p>This is my personal portfolio website. Here you can find more information about me and my work.</p>
    </div>
  );
}

export default Home;
