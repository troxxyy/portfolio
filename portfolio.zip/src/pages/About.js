
import React from 'react';

function About() {
  return (
    <div>
      <h1>About Me</h1>
      <p>My name is Sina Cetinkaya. I am a Fullstack Developer with expertise in AR/VR environments.</p>
      <a href="/path/to/Sina_Cetinkaya_ENG_.pdf" target="_blank">View Resume</a>
    </div>
  );
}

export default About;
